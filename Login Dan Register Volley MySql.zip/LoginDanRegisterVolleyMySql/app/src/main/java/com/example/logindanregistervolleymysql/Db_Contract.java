package com.example.logindanregistervolleymysql;

public class Db_Contract {

    public static String ip = "192.168.18.13";

    public static String urlRegister = "http://"+ip+"//my_api_android/api-register.php";
    public static String urlLogin = "http://"+ip+"//my_api_android/api-login.php";
}
